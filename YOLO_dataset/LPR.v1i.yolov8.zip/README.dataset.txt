# LPR > 2023-09-28 11:05pm
https://universe.roboflow.com/university-of-padova-gfi4l/lpr-zlj3c

Provided by a Roboflow user
License: Public Domain

